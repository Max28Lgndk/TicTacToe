<!doctype html>
<html lang="en">
<head>
    <meta name="viewport" content=
    "width=device-width, initial-scale=1.0">
    <link rel="stylesheet"
          type="text/css" href="../css/styles.css">
    <script src="../js/javascript.js"></script>
    <title>Boter,Kaas en Eieren</title>
</head>
<!-- nav bar -->
<body>
    <h1 class="game--title">Boter, Kaas & Eieren</h1>
    <nav>
        <a href="../Index/Index.php">Home</a>
        <a href="spel-home2.php">Spel</a>
        <a href="prijzen.php">Prijzen</a>
        <a href="../inlog/login.php">Profiel</a>
        <a href="contact.php">Contact</a>
        <div class="animation start-spel"></div>
    </nav>
    <div class="bke_1v1">
        <h1 class="bke_1v1_h1">Gamemode: 1 v 1</h1>
        <hr>
        <br><br>
        <p class="p_bke_home_1v1"> Boter-kaas-en-eieren wordt gespeeld op 3 bij 3 velden.
            Bij het begin zijn alle velden leeg.
            De ene speler zet een 'kruis' en de andere speler een 'rondje'.</p>
        <br>
        <p class="p_bke_home_1v1">Degene die drie van zijn eigen tekens op een rij heeft,
            dat mag diagonaal,
            verticaal of horizontaal zijn,
            heeft gewonnen.</p>
    </div>
    <div class="bke_1v1_online">
        <h1 class="bke_1v1_h1">Gamemode: 1 v 1 Online</h1>
        <hr>
        <br><br>
        <p class="p_bke_home_1v1"> Boter-kaas-en-eieren wordt gespeeld op 3 bij 3 velden.
            Bij het begin zijn alle velden leeg.
            De ene speler zet een 'kruis' en de andere speler een 'rondje'.</p>
        <br>
        <p class="p_bke_home_1v1">Degene die drie van zijn eigen tekens op een rij heeft,
            dat mag diagonaal,
            verticaal of horizontaal zijn,
            heeft gewonnen.</p>
    </div>
    <div class="bke_1vAi">
        <h1 class="bke_1v1_h1">Gamemode: 1 v AI</h1>
        <hr>
        <br><br>
        <p class="p_bke_home_1v1"> Boter-kaas-en-eieren wordt gespeeld op 3 bij 3 velden.
            Bij het begin zijn alle velden leeg.
            De ene speler zet een 'kruis' en de andere speler een 'rondje'.</p>
        <br>
        <p class="p_bke_home_1v1">Degene die drie van zijn eigen tekens op een rij heeft,
            dat mag diagonaal,
            verticaal of horizontaal zijn,
            heeft gewonnen.</p>
    </div>
    <div class="test">
    <button onclick="document.location='bke_spel.php'">HTML Tutorial</button>
    </div>
</body>
</html>